<!DOCTYPE html>
<html>
	<head>
		<title>Titre P</title>
	</head>
	<body>
		<?php
		echo "Tu as cliqué sur oui hihihi" ;
		?>
	</body>
</html>